import openpyxl

wb_f = openpyxl.load_workbook('/home/ubuntu/upload/Personal-Wealth-Tracker.xlsx', data_only=False)
wb_v = openpyxl.load_workbook('/home/ubuntu/upload/Personal-Wealth-Tracker.xlsx', data_only=True)

for name in wb_f.sheetnames:
    ws_f = wb_f[name]
    ws_v = wb_v[name]
    print('='*70)
    print('SHEET:', name)
    print('='*70)
    for row in range(1, ws_f.max_row+1):
        cells = []
        for col in range(1, ws_f.max_column+1):
            cf = ws_f.cell(row=row, column=col)
            cv = ws_v.cell(row=row, column=col)
            formula = cf.value
            value = cv.value
            if formula is None and value is None:
                continue
            coord = cf.coordinate
            if isinstance(formula, str) and formula.startswith('='):
                cells.append(f'{coord}=[{formula}] -> {value}')
            else:
                cells.append(f'{coord}: {formula}')
        if cells:
            print(f'R{row}: ' + ' | '.join(cells))
    print()
