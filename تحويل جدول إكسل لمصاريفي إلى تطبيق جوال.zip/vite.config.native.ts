// إعداد Vite نظيف لبناء تطبيق أندرويد الأصلي (APK) — بدون أي إضافات خاصة بمنصة Manus
// (لا manus-runtime، لا debug-collector، لا storage-proxy) لضمان عمل JavaScript داخل WebView
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "node:path";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  base: "./",
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist-native"),
    emptyOutDir: true,
  },
});
